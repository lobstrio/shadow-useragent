from .core import ShadowUserAgent

name = "shadow_useragent"
