# shadow-useragent
Always keep your user-agent updated with the most recent and most common user-agents
