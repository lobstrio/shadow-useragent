from .core import ShadowUserAgent

name = "shadow-useragent"
